package com.jsf.springmvc.rest.webservices.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import com.jsf.springmvc.rest.webservices.model.Customer;
import com.jsf.springmvc.rest.webservices.model.DropDownList;
import com.jsf.springmvc.rest.webservices.model.Employee;

public interface EmployeeService {
	public String createOrUpdateEmployee(Employee employee, String operation) throws IOException, SQLException;

	public String addDropDownItem(DropDownList dropDownItem) throws IOException, SQLException;

	public List<DropDownList> getDropDownList() throws IOException, SQLException;

	public List<Employee> getEmployeeList() throws IOException, SQLException;
}
