package com.jsf.springmvc.rest.webservices.customexceptions;

/**
 * 
 * @author EI11321
 *   EmailAlreadyExists -- custom runtime exception class
 */
public class EmailAlreadyExists extends RuntimeException {
	private static final long serialVersionUID = -477715430896564464L;

	public EmailAlreadyExists(String exceptionMessage) {
		super(exceptionMessage);
	}
}
