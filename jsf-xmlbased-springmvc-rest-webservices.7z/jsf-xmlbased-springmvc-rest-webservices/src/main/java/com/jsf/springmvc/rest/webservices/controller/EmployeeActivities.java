package com.jsf.springmvc.rest.webservices.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.jsf.springmvc.rest.webservices.customexceptions.NoRecordsFound;
import com.jsf.springmvc.rest.webservices.model.DropDownList;
import com.jsf.springmvc.rest.webservices.model.Employee;
import com.jsf.springmvc.rest.webservices.service.EmployeeService;
import com.jsf.springmvc.rest.webservices.util.OperationStatus;

/**
 * 
 * @author EI11321
 * 
 *  EmployeeActivities is a controller used to map to the corresponding
 *         request handler method based on the url pattern passed in the URL
 *
 */
@RestController
public class EmployeeActivities {
	private static final Logger logger = Logger.getLogger(EmployeeActivities.class);
	
	// @Autowired is used to identify the respective bean class in spring application context and inject it's object.
	@Autowired
	private EmployeeService employeeService;

	
	
	/**
	 * 
	 * @param employee
	 * @return ResponseEntity<String>
	 * @throws IOException
	 * @throws SQLException
	 * 
	 * this method is used to convert JSON request into employee object by using @RequestBody and pass it to the method of employee service layer to enroll employee.
	 * based on the status received from the called method, corresponding response is sent back.
	 * 
	 * @PostMapping -- this acts as both @RequestMapping and HTTP method 'POST'
	 */
	@PostMapping("/employee")
	public ResponseEntity<String> createEmployee(@RequestBody Employee employee) throws IOException, SQLException {
		ResponseEntity<String> responseEntity = null;
		logger.info("******* Entered into createEmployee() method******* ");
		logger.info("************Details from model object ******* :" + employee.getName() + ","
				+ employee.getDesignation() + "," + employee.getDateOfBirth() + "," + employee.getDepartment() + ","
				+ employee.getReportTo() + "," + employee.getGender() + "," + employee.getDateOfJoining() + ","
				+ employee.getPrimarySkill() + "," + employee.getStartDate() + "," + employee.getEndDate() + ","
				+ employee.getLocation() + "," + employee.getUploadedImage());
		String operation = "create";
		String creationStatus = employeeService.createOrUpdateEmployee(employee, operation);
		if (creationStatus.equals(OperationStatus.SUCCESS)) {
			responseEntity = new ResponseEntity<>(creationStatus, HttpStatus.OK);
		}
		return responseEntity;
	}

	
	/**
	 * 
	 * @param employee
	 * @return ResponseEntity<String>
	 * @throws IOException
	 * @throws SQLException
	 * 
	 * this method is used to convert JSON request into employee object by using @RequestBody and pass it to the method of employee service layer to update the employee.
	 * based on the status received from the called method, corresponding response is sent back.
	 * 
	 * @PostMapping -- this acts as both @RequestMapping and HTTP method 'POST'
	 * 
	 */
	@PostMapping("/employee/{id}")
	public ResponseEntity<String> updateEmployee(@RequestBody Employee employee) throws IOException, SQLException {
		ResponseEntity<String> responseEntity = null;
		logger.info("*******Entered into updateEmployee() method***********");
		logger.info("*********Details from model object  at webservice side********** :" + employee.getId() + ","
				+ employee.getName() + "," + employee.getDesignation() + "," + employee.getDateOfBirth() + ","
				+ employee.getDepartment() + "," + employee.getReportTo() + "," + employee.getGender() + ","
				+ employee.getDateOfJoining() + "," + employee.getPrimarySkill() + "," + employee.getStartDate() + ","
				+ employee.getEndDate() + "," + employee.getLocation() + "," + employee.getUploadedImage());
		String operation = "update";
		String updationStatus = employeeService.createOrUpdateEmployee(employee, operation);
		if (updationStatus.equals(OperationStatus.SUCCESS)) {
			responseEntity = new ResponseEntity<>(updationStatus, HttpStatus.OK);
		}
		return responseEntity;
	}

	
	/**
	 * 
	 * @param dropDownItem
	 * @return ResponseEntity<String>
	 * @throws IOException
	 * @throws SQLException
	 * 
	 * this method is to create the drop down item where as JSON request received is converted into DropDownList object
	 * by using @RequestBody and pass it to addDropDownItem() method of employee service layer.
	 * 
	 * @PostMapping -- this acts as both @RequestMapping and HTTP method 'POST'
	 */
	@PostMapping("/dropDown")
	public ResponseEntity<String> addDropDownItem(@RequestBody DropDownList dropDownItem)
			throws IOException, SQLException {
		ResponseEntity<String> responseEntity = null;
		String itemCreationStatus = employeeService.addDropDownItem(dropDownItem);
		if (itemCreationStatus.equals(OperationStatus.SUCCESS)) {
			responseEntity = new ResponseEntity<>(itemCreationStatus, HttpStatus.OK);
		}
		return responseEntity;
	}

	/**
	 * 
	 * @return ResponseEntity<List<DropDownList>>
	 * @throws IOException
	 * @throws SQLException
	 * 
	 * this method is used to retrieve the list of drop down items by invoking the getDropDownList() method of employee service layer.
	 * 
	 * @GetMapping acts as both @RequestMapping and HTTP method 'GET'
	 */
	@GetMapping("/dropDownList")
	public ResponseEntity<List<DropDownList>> getDropDownList() throws IOException, SQLException {
		List<DropDownList> dropDownList = null;
		ResponseEntity<List<DropDownList>> responseEntity = null;
		dropDownList = employeeService.getDropDownList();
		if (dropDownList != null) {
			logger.info("Size of the drop down List retrieved  : " + dropDownList.size());
			if (dropDownList.size() > 0) {
				responseEntity = new ResponseEntity<>(dropDownList, HttpStatus.OK);
			} else {
				logger.info("no records found exception is thrown from controller");
				throw new NoRecordsFound("No records existed");
			}
		}
		return responseEntity;
	}

	/**
	 * 
	 * @return ResponseEntity<List<Employee>>
	 * @throws IOException
	 * @throws SQLException
	 * 
	 * this method is to retrieve the list of employees by invoking the getEmployeeList() of employee service layer.
	 * 
	 * @GetMapping acts as both @RequestMapping and HTTP method 'GET'
	 */
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getEmployeeList() throws IOException, SQLException {
		List<Employee> employeeList = null;
		ResponseEntity<List<Employee>> responseEntity = null;
		employeeList = employeeService.getEmployeeList();
		if (employeeList != null) {
			logger.info("Size of the List retrieved  : " + employeeList.size());
			if (employeeList.size() > 0) {
				responseEntity = new ResponseEntity<>(employeeList, HttpStatus.OK);
			} else {
				logger.info("no records found exception is thrown from controller");
				throw new NoRecordsFound("No records existed");
			}
		}
		for (Employee employee : employeeList) {
			logger.info("*****size of pomotions of employee is : " + employee.getPromotionList().size());
		}
		return responseEntity;
	}
}
