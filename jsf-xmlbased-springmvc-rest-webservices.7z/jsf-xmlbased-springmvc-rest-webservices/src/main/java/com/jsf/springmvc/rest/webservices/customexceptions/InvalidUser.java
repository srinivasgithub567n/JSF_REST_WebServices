package com.jsf.springmvc.rest.webservices.customexceptions;

/**
 * 
 * @author EI11321
 *   InvalidUser -- custom runtime exception class
 */
public class InvalidUser extends RuntimeException {
	private static final long serialVersionUID = -3728251363314809491L;

	public InvalidUser(String exceptionMessage) {
		super(exceptionMessage);
	}
}
