package com.jsf.springmvc.rest.webservices.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 
 * @author srinivasa.nayana
 *
 */
public class HibernateUtil {
	// autowired annotation is used to inject the session factory object implicitly
	// .
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;

	/**
	 * 
	 * @return Session
	 */
	public Session getSession() {
		session = sessionFactory.getCurrentSession();
		return session;
	}

	/**
	 * to close the session factory
	 */
	public void closeSessionFactory() {
		sessionFactory.close();
	}
}
