package com.jsf.springmvc.rest.webservices.customexceptions;


/**
 * 
 * @author EI11321
 *   UserNotExist -- custom runtime exception class
 */
public class UserNotExist extends RuntimeException {
	private static final long serialVersionUID = -1525074076167906277L;

	public UserNotExist(String exceptionMessage) {
		super(exceptionMessage);
	}
}
