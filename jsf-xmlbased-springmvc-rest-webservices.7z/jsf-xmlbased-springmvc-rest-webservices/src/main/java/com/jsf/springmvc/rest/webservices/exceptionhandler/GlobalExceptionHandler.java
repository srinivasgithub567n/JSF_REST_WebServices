package com.jsf.springmvc.rest.webservices.exceptionhandler;

import java.io.IOException;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.jsf.springmvc.rest.webservices.customexceptions.EmailAlreadyExists;
import com.jsf.springmvc.rest.webservices.customexceptions.InvalidUser;
import com.jsf.springmvc.rest.webservices.customexceptions.NoRecordsFound;
import com.jsf.springmvc.rest.webservices.customexceptions.UpdateToInactiveEmployee;
import com.jsf.springmvc.rest.webservices.customexceptions.UserNotExist;

/**
 * 
 * @author srinivasa.nayana
 *
 *         class GlobalExceptionHandler is a controller advice which contains
 *         the exception handler methods. when any exception is raised in any of
 *         the controller classes of sprig, then spring scans the class which
 *         are annotated with ControllerAdvice to see if there is any suitable
 *         exception handler method is defined to execute.
 * 
 *         if nothing found , then it's been handed over to default exception
 *         handler.
 * 
 *         here every exception handler method must be annotated
 *         with @ExceptionHandler
 */
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
	private static final Logger logger = Logger.getLogger(GlobalExceptionHandler.class);

	// NullPointerException handler method
	@ExceptionHandler(value = NullPointerException.class)
	protected ResponseEntity<Object> handleNullPointerException(NullPointerException exception) {
		logger.error("NullPointer Exception Occured", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// IOException handler method
	@ExceptionHandler(value = IOException.class)
	protected ResponseEntity<Object> handleIOException(IOException exception) {
		logger.error("IO Exception Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// SQLException handler method
	@ExceptionHandler(value = SQLException.class)
	protected ResponseEntity<Object> handleSQLException(SQLException exception) {
		logger.error("SQL Exception Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// ArithmeticException handler method
	@ExceptionHandler(value = ArithmeticException.class)
	protected ResponseEntity<Object> handleArithmeticException(ArithmeticException exception) {
		logger.error("Arithmetic Exception Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// ArrayIndexOutOfBoundsException handler method
	@ExceptionHandler(value = ArrayIndexOutOfBoundsException.class)
	protected ResponseEntity<Object> handleArrayIndexOutOfBoundsException(ArrayIndexOutOfBoundsException exception) {
		logger.error("ArrayIndexOutOfBounds Exception Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// ClassCastException handler method
	@ExceptionHandler(value = ClassCastException.class)
	protected ResponseEntity<Object> handleClassCastException(ClassCastException exception) {
		logger.error("ClassCastException Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// IllegalArgumentException handler method
	@ExceptionHandler(value = IllegalArgumentException.class)
	protected ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException exception) {
		logger.error("IllegalArgumentException Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// NumberFormatException handler method
	@ExceptionHandler(value = NumberFormatException.class)
	protected ResponseEntity<Object> handleNumberFormatException(NumberFormatException exception) {
		logger.error("NumberFormatException Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// Generic Exception handler method
	@ExceptionHandler(value = Exception.class)
	protected ResponseEntity<Object> handleException(Exception exception) {
		logger.error("Exception Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// InvalidUser custom exception handler method
	@ExceptionHandler(value = InvalidUser.class)
	protected ResponseEntity<Object> handleInvalidUserException(InvalidUser exception) {
		logger.error("InvalidUser Exception Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.UNAUTHORIZED);
	}

	// EmailAlreadyExists customer exception handler method
	@ExceptionHandler(value = EmailAlreadyExists.class)
	protected ResponseEntity<Object> handleEmailAlreadyExistsException(EmailAlreadyExists exception) {
		logger.error("EmailAlreadyExists Exception Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.ALREADY_REPORTED);
	}

	// UserNotExist custom exception handler method
	@ExceptionHandler(value = UserNotExist.class)
	protected ResponseEntity<Object> handleUserNotExistException(UserNotExist exception) {
		logger.error("UserNotExists Exception Occured", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.NO_CONTENT);
	}

	// NoRecordsFound custom exception handler method
	@ExceptionHandler(value = NoRecordsFound.class)
	protected ResponseEntity<Object> handleNoRecordsFoundException(NoRecordsFound exception) {
		logger.error("No Records Found Exception Occured ", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.CONFLICT);
	}

	// UpdateToInactiveEmployee custom exception handler method
	@ExceptionHandler(value = UpdateToInactiveEmployee.class)
	protected ResponseEntity<Object> UpdateToInactiveEmployeeException(UpdateToInactiveEmployee exception) {
		logger.error("Inactive Employee cannot be update Exception occured", exception);
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.CONFLICT);
	}
}
