package com.jsf.springmvc.rest.webservices.controller.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jsf.springmvc.rest.webservices.controller.LoginActivities;
import com.jsf.springmvc.rest.webservices.customexceptions.EmailAlreadyExists;
import com.jsf.springmvc.rest.webservices.customexceptions.NoRecordsFound;
import com.jsf.springmvc.rest.webservices.model.Customer;
import com.jsf.springmvc.rest.webservices.model.CustomerIds;
import com.jsf.springmvc.rest.webservices.model.Login;
import com.jsf.springmvc.rest.webservices.service.RegistrationService;
import com.jsf.springmvc.rest.webservices.util.OperationStatus;

public class LoginActivitiesTest {

	private static final Logger logger = Logger.getLogger(LoginActivitiesTest.class);

	private MockMvc mockMvc;

	@Mock
	private RegistrationService registrationServiceMock;

	@InjectMocks
	private LoginActivities loginActivites;

	@Before
	public void init() {
		logger.info("@Before is called ");
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(loginActivites).build();
	}

	@Test
	public void testCreateUser_success() throws Exception {

		Customer customerDetails = new Customer();
		customerDetails.setFirstName("Praveen");
		customerDetails.setLastName("Chinnam");
		customerDetails.setEmailId("praveen@gmail.com");
		customerDetails.setMobileNo(8888888888L);
		String operation = "create";
		String creationStatus = OperationStatus.SUCCESS;

		logger.info("User details from test method :" + customerDetails.getFirstName() + ","
				+ customerDetails.getLastName() + "," + customerDetails.getEmailId() + ","
				+ customerDetails.getMobileNo() + "," + customerDetails.getPassword() + "," + customerDetails.getId());
		when(registrationServiceMock.createOrUpdateUser(customerDetails, operation)).thenReturn(creationStatus);

		// assertEquals("success",registrationServiceMock.createOrUpdateUser(customerDetails,
		// operation));
		mockMvc.perform(post("/addUser").contentType(MediaType.APPLICATION_JSON)
				.content(LoginActivitiesTest.getObjectMapper().writeValueAsString(customerDetails)))
				.andExpect(status().isOk());
		verify(registrationServiceMock, times(1)).createOrUpdateUser(customerDetails, operation);
		verifyNoMoreInteractions(registrationServiceMock);

	}
	
	
	

	@Test
	public void testUpdateCustomer_success() throws Exception {

		Customer customerDetails = new Customer();
		customerDetails.setId(5);
		customerDetails.setFirstName("Praveen");
		customerDetails.setLastName("Chinnam");
		customerDetails.setEmailId("praveen@gmail.com");
		customerDetails.setMobileNo(8888888888L);
		String operation = "update";
		String creationStatus = OperationStatus.SUCCESS;

		logger.info("User details from test method :" + customerDetails.getFirstName() + ","
				+ customerDetails.getLastName() + "," + customerDetails.getEmailId() + ","
				+ customerDetails.getMobileNo() + "," + customerDetails.getPassword() + "," + customerDetails.getId());
		when(registrationServiceMock.createOrUpdateUser(customerDetails, operation)).thenReturn(creationStatus);

		 //assertEquals("success",registrationServiceMock.createOrUpdateUser(customerDetails, operation));
		mockMvc.perform(put("/customers/{id}", customerDetails.getId()).contentType(MediaType.APPLICATION_JSON)
				.content(LoginActivitiesTest.getObjectMapper().writeValueAsString(customerDetails)))
				.andExpect(status().isOk());
		verify(registrationServiceMock, times(1)).createOrUpdateUser(customerDetails, operation);
		verifyNoMoreInteractions(registrationServiceMock);

	}

	@Test
	public void testLoginVerify_success() throws Exception {

		Login loginCredentials = new Login();
		loginCredentials.setEmailId("srinivas@gmail.com");
		loginCredentials.setPassword("srinivas123123");
		Customer loggedInUser = new Customer();
		loggedInUser.setId(5);
		loggedInUser.setFirstName("srinivasa rao");
		loggedInUser.setLastName("nayana");
		loggedInUser.setEmailId("srinivas@gmail.com");
		loggedInUser.setMobileNo(5555566666L);
		when(registrationServiceMock.loginVerify(loginCredentials)).thenReturn(loggedInUser);
		mockMvc.perform(post("/loginVerify").contentType(MediaType.APPLICATION_JSON)
				.content(LoginActivitiesTest.getObjectMapper().writeValueAsString(loginCredentials)))
				.andExpect(status().isOk());

	}

	@Test
	public void testGetCustomers_success() throws Exception {
		Customer customerOne = new Customer();
		customerOne.setFirstName("Srinivasa Rao");
		customerOne.setLastName("Nayana");
		customerOne.setEmailId("srinivas@gmail.com");
		customerOne.setMobileNo(9999999999L);
		Customer customerTwo = new Customer();
		customerTwo.setFirstName("Manoj");
		customerTwo.setLastName("Kulkarni");
		customerTwo.setEmailId("manoj@ymail.com");
		customerTwo.setMobileNo(8282828282L);
		List<Customer> customersList = Arrays.asList(customerOne, customerTwo);
		when(registrationServiceMock.getCustomers()).thenReturn(customersList);
		mockMvc.perform(get("/customers")).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
		verify(registrationServiceMock, times(1)).getCustomers();
		verifyNoMoreInteractions(registrationServiceMock);

	}
	

	@Test
	public void testDeleteCustomer_success() throws Exception {
		String creationStatus = OperationStatus.SUCCESS;
		int customerId = 5;
		CustomerIds customerIds = new CustomerIds();
		customerIds.setCustomerIds(new int[1]);
		customerIds.getCustomerIds()[0] = customerId;
		when(registrationServiceMock.deleteOneOrMutipleCustomers(customerIds)).thenReturn(creationStatus);
		mockMvc.perform(delete("/customers/{id}", customerId).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
		verify(registrationServiceMock, times(1)).deleteOneOrMutipleCustomers(customerIds);
		verifyNoMoreInteractions(registrationServiceMock);

	}

	@Test
	public void testDeleteCustomers_success() throws Exception {

		CustomerIds customerIds = new CustomerIds();
		customerIds.setCustomerIds(new int[2]);
		customerIds.getCustomerIds()[0] = 5;
		customerIds.getCustomerIds()[1] = 10;
		String creationStatus = OperationStatus.SUCCESS;
		when(registrationServiceMock.deleteOneOrMutipleCustomers(customerIds)).thenReturn(creationStatus);
		mockMvc.perform(delete("/customers").contentType(MediaType.APPLICATION_JSON)
				.content(LoginActivitiesTest.getObjectMapper().writeValueAsString(customerIds)))
				.andExpect(status().isOk());
		verify(registrationServiceMock, times(1)).deleteOneOrMutipleCustomers(customerIds);
		verifyNoMoreInteractions(registrationServiceMock);

	}
	
	@Test(expected=EmailAlreadyExists.class)
	public void testCreateUser_EmailAlreadyExistsException() throws Throwable{

		Customer customerDetails = new Customer();
		customerDetails.setFirstName("Praveen");
		customerDetails.setLastName("Chinnam");
		customerDetails.setEmailId("praveen@gmail.com");
		customerDetails.setMobileNo(8888888888L);
		String operation = "create";
		

		logger.info("User details from test method :" + customerDetails.getFirstName() + ","
				+ customerDetails.getLastName() + "," + customerDetails.getEmailId() + ","
				+ customerDetails.getMobileNo() + "," + customerDetails.getPassword() + "," + customerDetails.getId());
		EmailAlreadyExists emailAlreadyExistsExpected=new EmailAlreadyExists("email already exists. please try some other one");
	

		
		try {
			when(registrationServiceMock.createOrUpdateUser(customerDetails, operation)).thenThrow(new EmailAlreadyExists("email already exists. please try some other one"));
		mockMvc.perform(post("/addUser").contentType(MediaType.APPLICATION_JSON)
				.content(LoginActivitiesTest.getObjectMapper().writeValueAsString(customerDetails)));
		
		}
		catch(NestedServletException nestedServletException)
		{
			logger.info(nestedServletException.getCause());
			if(nestedServletException.getCause() instanceof EmailAlreadyExists)
			{
			throw nestedServletException.getCause();
			}
		}
		verify(registrationServiceMock, times(1)).createOrUpdateUser(customerDetails, operation);
		verifyNoMoreInteractions(registrationServiceMock);
		
		

	}
	
	@Test(expected=NoRecordsFound.class)
	public void testGetCustomers_NoRecordsFoundException() throws Throwable {
		
		List<Customer> customersList = Arrays.asList();
		NoRecordsFound noRecordsFoundException=new NoRecordsFound("No records existed");
		
		when(registrationServiceMock.getCustomers()).thenReturn(customersList);
		
		try {
		mockMvc.perform(get("/customers")).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
		}
		catch(NestedServletException nestedServletException)
		{
			logger.info(nestedServletException.getCause());
			if(nestedServletException.getCause() instanceof NoRecordsFound)
			{
			throw nestedServletException.getCause();
			}
		}
		verify(registrationServiceMock, times(1)).getCustomers();
		verifyNoMoreInteractions(registrationServiceMock);
	
	}


	public static ObjectMapper getObjectMapper() {
		ObjectMapper objectMapper = null;

		if (objectMapper == null) {
			objectMapper = new ObjectMapper();
		}
		return objectMapper;
	}

}
