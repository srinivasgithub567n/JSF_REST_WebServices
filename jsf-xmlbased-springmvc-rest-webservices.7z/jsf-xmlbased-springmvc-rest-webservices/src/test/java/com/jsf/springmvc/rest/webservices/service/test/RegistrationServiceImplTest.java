package com.jsf.springmvc.rest.webservices.service.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.jsf.springmvc.rest.webservices.controller.LoginActivities;
import com.jsf.springmvc.rest.webservices.dao.RegistrationDao;
import com.jsf.springmvc.rest.webservices.model.Customer;
import com.jsf.springmvc.rest.webservices.model.Login;
import com.jsf.springmvc.rest.webservices.service.RegistrationService;
import com.jsf.springmvc.rest.webservices.service.RegistrationServiceImpl;

public class RegistrationServiceImplTest {
	
	private static final Logger logger=Logger.getLogger(RegistrationServiceImplTest.class);
	
	

	@Mock
	private RegistrationDao registrationDao;

	@InjectMocks
	private RegistrationServiceImpl registrationServiceImpl;
	
	@Before
	public void init() {
		logger.info("@Before is called ");
		MockitoAnnotations.initMocks(this);
		
	}

	@Test
	public void testCreateOrUpdateUser() {
		
	}

	@Test
	public void testLoginVerify() throws IOException, SQLException {
		
	
		
	}

	@Test
	public void testGetCustomers_success() throws IOException, SQLException {
		
		Customer customerOne = new Customer();
		customerOne.setFirstName("Srinivasa Rao");
		customerOne.setLastName("Nayana");
		customerOne.setEmailId("srinivas@gmail.com");
		customerOne.setMobileNo(9999999999L);
		Customer customerTwo = new Customer();
		customerTwo.setFirstName("Manoj");
		customerTwo.setLastName("Kulkarni");
		customerTwo.setEmailId("manoj@ymail.com");
		customerTwo.setMobileNo(8282828282L);
		List<Customer> customersList = Arrays.asList(customerOne, customerTwo);
		when(registrationDao.getCustomers()).thenReturn(customersList);
		List<Customer> customersListReturned=registrationServiceImpl.getCustomers();
	    assertNotNull(customersListReturned);
	    assertTrue(customersListReturned.size()>0);
		
	}

	@Test
	public void testDeleteOneOrMutipleCustomers() {
		
	}

}
