package com.jsf.springmvc.rest.webservices.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.jsf.springmvc.rest.webservices.customexceptions.EmailAlreadyExists;
import com.jsf.springmvc.rest.webservices.customexceptions.InvalidUser;
import com.jsf.springmvc.rest.webservices.customexceptions.UserNotExist;
import com.jsf.springmvc.rest.webservices.dao.RegistrationDao;
import com.jsf.springmvc.rest.webservices.model.Customer;
import com.jsf.springmvc.rest.webservices.model.CustomerIds;
import com.jsf.springmvc.rest.webservices.model.Login;


@ContextConfiguration(locations = "classpath:application-context-servlet-test.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class RegistrationDaoImplTest {

	@Autowired
	private RegistrationDao  registrationDao;
	
	
	@Test
	@Transactional(propagation=Propagation.REQUIRED)
  //  @Rollback(true)
	public void testCreateOrUpdateUser_create_success() throws IOException, SQLException {
		
		Customer customerDetails=new Customer();
		customerDetails.setFirstName("Praveen");
		customerDetails.setLastName("chakrapani");
		customerDetails.setEmailId("praveen@gmail.com");
		customerDetails.setMobileNo(7777777777L);
		customerDetails.setPassword("praveen098098");
		String operation="create";
		
		
		String userCreationStatus=registrationDao.createOrUpdateUser(customerDetails, operation);
		assertEquals("success",userCreationStatus);
		
	}
	
	@Test
	@Transactional(propagation=Propagation.REQUIRED)
//    @Rollback(true)
	public void testCreateOrUpdateUser_update_success() throws IOException, SQLException {
		
		Customer customerDetails=new Customer();
		customerDetails.setId(115);
		customerDetails.setFirstName("Praveen");
		customerDetails.setLastName("chakrapani");
		customerDetails.setEmailId("praveen@gmail.com");
		customerDetails.setMobileNo(7777777777L);
		customerDetails.setPassword("praveen098098");
		String operation="update";
		
		
		String userCreationStatus=registrationDao.createOrUpdateUser(customerDetails, operation);
		assertEquals("success",userCreationStatus);
		
	}
	
	
	@Test(expected=EmailAlreadyExists.class)
	@Transactional(propagation=Propagation.REQUIRED)
  //  @Rollback(true)
	public void testCreateOrUpdateUser_EmailAlreadyExistsException() throws IOException, SQLException {
		
		Customer customerDetails=new Customer();
		customerDetails.setFirstName("Praveen");
		customerDetails.setLastName("chakrapani");
		customerDetails.setEmailId("srinivas@gmail.com");
		customerDetails.setMobileNo(7777777777L);
		customerDetails.setPassword("praveen098098");
		String operation="create";
		
		
		String userCreationStatus=registrationDao.createOrUpdateUser(customerDetails, operation);
		
	}
	
	
	@Test(expected=UserNotExist.class)
	@Transactional(propagation=Propagation.REQUIRED)
  //  @Rollback(true)
	public void testCreateOrUpdateUser_UserNotExistException() throws IOException, SQLException {
		
		Customer customerDetails=new Customer();
		customerDetails.setId(1);
		customerDetails.setFirstName("Praveen");
		customerDetails.setLastName("chakrapani");
		customerDetails.setEmailId("praveen@gmail.com");
		customerDetails.setMobileNo(7777777777L);
		customerDetails.setPassword("praveen098098");
		String operation="update";
		
		
		String userCreationStatus=registrationDao.createOrUpdateUser(customerDetails, operation);
		
	}
	
	

	@Test
	public void testLoginVerify_success() throws IOException, SQLException {
		
		Login loginCredentials=new Login();
		loginCredentials.setEmailId("srinivas@gmail.com");
		loginCredentials.setPassword("srini123123");
		
		Customer loggedInUserExpected=new Customer();
		loggedInUserExpected.setId(115);
		loggedInUserExpected.setEmailId("srinivas@gmail.com");
		loggedInUserExpected.setFirstName("Srinivasa Rao");
		loggedInUserExpected.setLastName("nayana");
		loggedInUserExpected.setMobileNo(8383838838L);
		loggedInUserExpected.setPassword("srini123123");
		
		
		Customer loggedInUserActual=registrationDao.loginVerify(loginCredentials);
		assertEquals(loggedInUserExpected.getId(),loggedInUserActual.getId());
		assertEquals(loggedInUserExpected.getEmailId(),loggedInUserActual.getEmailId());
		assertEquals(loggedInUserExpected.getMobileNo(),loggedInUserActual.getMobileNo());
		assertEquals(loggedInUserExpected.getPassword(),loggedInUserActual.getPassword());
		
		
		
	}
	
	@Test(expected=InvalidUser.class)
	public void testLoginVerify_InvalidUserException() throws IOException, SQLException {
		
		Login loginCredentials=new Login();
		loginCredentials.setEmailId("test@gmail.com");
		loginCredentials.setPassword("test098098");
		Customer loggedInUserActual=registrationDao.loginVerify(loginCredentials);
		}

	@Test
	public void testGetCustomers_success() throws IOException, SQLException {
		
		List<Customer> customersList=registrationDao.getCustomers();
		assertNotNull(customersList);
		assertTrue(customersList.size()>0);
		
		}

	@Test
	@Transactional(propagation=Propagation.REQUIRED)
	public void testDeleteOneOrMutipleCustomers_success() throws IOException, SQLException {
		
		int id=115;
		CustomerIds customerIds=new CustomerIds();
		customerIds.setCustomerIds(new int[1]);
		customerIds.getCustomerIds()[0] =id;
		String deletionStatus=registrationDao.deleteOneOrMutipleCustomers(customerIds);
		assertEquals("success",deletionStatus);
		
	}
	
	@Test(expected=UserNotExist.class)
	@Transactional(propagation=Propagation.REQUIRED)
	public void testDeleteOneOrMutipleCustomers_UserNotExistException() throws IOException, SQLException {
		
		int id=1;
		CustomerIds customerIds=new CustomerIds();
		customerIds.setCustomerIds(new int[1]);
		customerIds.getCustomerIds()[0] =id;
		String deletionStatus=registrationDao.deleteOneOrMutipleCustomers(customerIds);
		
		
	}

}
