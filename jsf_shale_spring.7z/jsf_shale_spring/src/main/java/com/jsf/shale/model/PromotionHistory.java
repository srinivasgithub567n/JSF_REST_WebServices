package com.jsf.shale.model;

import java.util.Date;

/**
 * 
 * @author EI11321
 *
 *this is a model class to represent the object of employee promotion
 */
public class PromotionHistory {
	private int id;
	private String designation;
	private Date startDate;
	private Date endDate;
	private String startDateS;
	private String endDateS;

	/**
	 * 
	 * @return the startDateS
	 */
	public String getStartDateS() {
		return startDateS;
	}

	/**
	 * 
	 * @param startDateS 
	 * 
	 *  the startDateS to set
	 */
	public void setStartDateS(String startDateS) {
		this.startDateS = startDateS;
	}

	/**
	 * 
	 * @return endDateS
	 */
	public String getEndDateS() {
		return endDateS;
	}

	/**
	 * 
	 * @param endDateS
	 *   the endDateS to set
	 */
	public void setEndDateS(String endDateS) {
		this.endDateS = endDateS;
	}

	/**
	 * 
	 * @return startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * 
	 * @param startDate
	 *   the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * 
	 * @return endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * 
	 * @param endDate
	 * 
	 *  the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}

	/**
	 * @param designation
	 *            the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}
}
