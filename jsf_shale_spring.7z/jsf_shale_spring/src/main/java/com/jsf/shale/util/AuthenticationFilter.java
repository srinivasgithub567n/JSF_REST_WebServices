package com.jsf.shale.util;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

/**
 * 
 * @author srinivasa.nayana this class is used as authentication filter.
 */
public class AuthenticationFilter implements Filter {
	private static final Logger logger = Logger.getLogger(AuthenticationFilter.class);

	/**
	 * this method is called at the time of filter initialized
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		logger.info("Authentication filter is initialized");
	}

	/**
	 * @param request
	 * @param response
	 * @param chain
	 * 
	 *            this method is used to filter the JSF pages based on the session
	 *            management
	 * 
	 * 
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		HttpSession httpSession = httpRequest.getSession(false);
		String requestURI = ((HttpServletRequest) request).getRequestURI();
		logger.info("HttpSession reference is : " + httpSession);
		logger.info("Request URI is :" + requestURI);
		logger.info("Request path is :" + ((HttpServletRequest) request).getPathInfo());
		if (httpSession == null) {
			if (requestURI.contains("home_page.jsp")) {
				chain.doFilter(request, response);
			} else {
				httpResponse.sendRedirect(httpRequest.getContextPath() + "/faces/home_page.jsp");
			}
		} else {
			if (httpSession.getAttribute("user") != null) {
				chain.doFilter(request, response);
			} else if (requestURI.contains("home_page.jsp")) {
				chain.doFilter(request, response);
			} else if (requestURI.contains("registration_form.jsp")) {
				chain.doFilter(request, response);
			} else {
				httpResponse.sendRedirect(httpRequest.getContextPath() + "/faces/home_page.jsp");
			}
		}
	}

	/**
	 * this method is called at the filter destruction
	 */
	public void destroy() {
		logger.info("Authentication filter is destroyed ");
	}
}
