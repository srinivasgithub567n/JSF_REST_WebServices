package com.jsf.shale;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
/**
 * 
 * @author EI11321
 * 
 * this servlet class is used to pass the binary data of uploaded image to the graphicImage component of JSF view ( both enrollment 
 * 
 * and edit form)
 *
 */
public class ImageServlet extends HttpServlet {
	private static final Logger logger = Logger.getLogger(ImageServlet.class);
	private static final long serialVersionUID = 1L;
	public static byte[] image;

	/**
	 * this method is responsible of passing the binary data to the graphicImage component to display image after uploading
	 *  or updating the photo.
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		logger.info("*********Image Servlet is called by graphic image component ************");
		if (image != null) {
			response.setContentType("image/jpeg");
			ServletOutputStream outputStream = response.getOutputStream();
			logger.info("********Image Data before sending to graphic image ********** :" + image);
			outputStream.write(image);
			logger.info("***********Image is sent from Image Servlet to graphicImage **********");
			outputStream.close();
		}
	}

	public static void sendImageBytes(byte[] image) {
		logger.info("********** Image Servlet method is called **********");
		ImageServlet.image = image;
	}
}
