package com.jsf.shale.model;

import java.util.Date;
import java.util.List;
import javax.faces.model.SelectItem;

public class Employee {
	private int id;
	private String name;
	private String designation;
	private Date dateOfBirth;
	private String department;
	private String reportTo;
	private String gender;
	private Date dateOfJoining;
	private String primarySkill;
	private Date startDate;
	private Date endDate;
	private String location;
	private String managerStatus;
	private byte[] uploadedImage;
	private String status;
	// to change from date to string and string to boolen to display in the details
	// in employee edit form
	private String dateOfBirthS;
	private String dateOfJoiningS;
	private String startDateS;
	private String endDateS;
	private boolean managerStatusB;
	private List<PromotionHistory> promotionList;
	private List<SelectItem> promotionItems;

	/**
	 * @return the promotionItems
	 */
	public List<SelectItem> getPromotionItems() {
		return promotionItems;
	}

	/**
	 * @param promotionItems
	 *            the promotionItems to set
	 */
	public void setPromotionItems(List<SelectItem> promotionItems) {
		this.promotionItems = promotionItems;
	}

	/**
	 * @return the promotionList
	 */
	public List<PromotionHistory> getPromotionList() {
		return promotionList;
	}

	/**
	 * @param promotionList
	 *            the promotionList to set
	 */
	public void setPromotionList(List<PromotionHistory> promotionList) {
		this.promotionList = promotionList;
	}

	/**
	 * @return the dateOfBirthS
	 */
	public String getDateOfBirthS() {
		return dateOfBirthS;
	}

	/**
	 * @param dateOfBirthS
	 *            the dateOfBirthS to set
	 */
	public void setDateOfBirthS(String dateOfBirthS) {
		this.dateOfBirthS = dateOfBirthS;
	}

	/**
	 * @return the dateOfJoiningS
	 */
	public String getDateOfJoiningS() {
		return dateOfJoiningS;
	}

	/**
	 * @param dateOfJoiningS
	 *            the dateOfJoiningS to set
	 */
	public void setDateOfJoiningS(String dateOfJoiningS) {
		this.dateOfJoiningS = dateOfJoiningS;
	}

	/**
	 * @return the startDateS
	 */
	public String getStartDateS() {
		return startDateS;
	}

	/**
	 * @param startDateS
	 *            the startDateS to set
	 */
	public void setStartDateS(String startDateS) {
		this.startDateS = startDateS;
	}

	/**
	 * @return the endDateS
	 */
	public String getEndDateS() {
		return endDateS;
	}

	/**
	 * @param endDateS
	 *            the endDateS to set
	 */
	public void setEndDateS(String endDateS) {
		this.endDateS = endDateS;
	}

	/**
	 * @return the managerStatusB
	 */
	public boolean isManagerStatusB() {
		return managerStatusB;
	}

	/**
	 * @param managerStatusB
	 *            the managerStatusB to set
	 */
	public void setManagerStatusB(boolean managerStatusB) {
		this.managerStatusB = managerStatusB;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the uploadedImage
	 */
	public byte[] getUploadedImage() {
		return uploadedImage;
	}

	/**
	 * @param uploadedImage
	 *            the uploadedImage to set
	 */
	public void setUploadedImage(byte[] uploadedImage) {
		this.uploadedImage = uploadedImage;
	}

	/**
	 * @return the managerStatus
	 */
	public String getManagerStatus() {
		return managerStatus;
	}

	/**
	 * @param managerStatus
	 *            the managerStatus to set
	 */
	public void setManagerStatus(String managerStatus) {
		this.managerStatus = managerStatus;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}

	/**
	 * @param designation
	 *            the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @param dateOfBirth
	 *            the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department
	 *            the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return the reportTo
	 */
	public String getReportTo() {
		return reportTo;
	}

	/**
	 * @param reportTo
	 *            the reportTo to set
	 */
	public void setReportTo(String reportTo) {
		this.reportTo = reportTo;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the dateOfJoining
	 */
	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	/**
	 * @param dateOfJoining
	 *            the dateOfJoining to set
	 */
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	/**
	 * @return the primarySkill
	 */
	public String getPrimarySkill() {
		return primarySkill;
	}

	/**
	 * @param primarySkill
	 *            the primarySkill to set
	 */
	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}

	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location
	 *            the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}
}
