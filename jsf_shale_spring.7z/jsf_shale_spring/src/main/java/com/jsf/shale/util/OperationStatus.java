package com.jsf.shale.util;

public class OperationStatus {
	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
	public static final String INVALID = "invalid";
	public static final String NO_DATA = "no_data";
	public static final String NOT_SELECTED_CHECKBOX = "not_selected_checkbox";
}
