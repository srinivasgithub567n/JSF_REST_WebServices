package com.jsf.shale;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.apache.myfaces.custom.fileupload.UploadedFile;
import com.jsf.shale.model.DropDownList;
import com.jsf.shale.model.Employee;
import com.jsf.shale.service.EmployeeService;
import com.jsf.shale.util.DTOComparator;
import com.jsf.shale.util.OperationStatus;

/**
 * 
 * @author EI11321
 * 
 * 'EmployeeEnrollment' class is a managed bean (backing bean) which is bound to the JFS view 'employee_enrollment.jsp'
 *
 */
public class EmployeeEnrollment {
	private static final Logger logger = Logger.getLogger(EmployeeEnrollment.class);
	private int id;
	private String name;
	private Map<String, Object> designation;
	private String dateOfBirth;
	private Map<String, Object> department;
	private Map<String, Object> reportTo;
	private Map<String, Object> gender;
	private String dateOfJoining;
	private Map<String, Object> primarySkill;
	private String startDate;
	private String endDate;
	private Map<String, Object> location;
	private boolean managerStatus;
	private String selectedDesignation;
	private String selectedDepartment;
	private String selectedReportTo;
	private String selectedGender = "Others";
	private String selectedPrimarySkill;
	private String selectedLocation;
	private EmployeeService employeeService;
	private UploadedFile upLoadedFile;
	private Employee employeeEditable = new Employee();
	private List<DropDownList> dropDownSet;
	private byte[] image;
	private Employee employeeEditableCopy = new Employee();
	private boolean renderComponent = true;
	private boolean disableComponent = false;
	private boolean renderUploadPhotoButton = true;
	private boolean renderChangePhotoLink = false;
	private String upLoadedFileName;
	private static EmployeeSummary employeeSummary;

	/**
	 * 
	 * @return the upLoadedFileName
	 */
	public String getUpLoadedFileName() {
		return upLoadedFileName;
	}

	/**
	 * 
	 * @param upLoadedFileName
	 * the upLoadedFileName to set
	 */
	public void setUpLoadedFileName(String upLoadedFileName) {
		this.upLoadedFileName = upLoadedFileName;
	}

	/**
	 * 
	 * @return the renderUploadPhotoButton
	 */
	public boolean isRenderUploadPhotoButton() {
		return renderUploadPhotoButton;
	}

	/**
	 * 
	 * @param renderUploadPhotoButton
	 *    the renderUploadPhotoButtont to set
	 */
	public void setRenderUploadPhotoButton(boolean renderUploadPhotoButton) {
		this.renderUploadPhotoButton = renderUploadPhotoButton;
	}

	/**
	 * 
	 * @return the renderChangePhotoLink
	 */
	public boolean isRenderChangePhotoLink() {
		return renderChangePhotoLink;
	}

	/**
	 * 
	 * @param renderChangePhotoLink
	 * the renderChangePhotoLink to set
	 */
	public void setRenderChangePhotoLink(boolean renderChangePhotoLink) {
		this.renderChangePhotoLink = renderChangePhotoLink;
	}

	/**
	 * 
	 * @return the renderComponent
	 */
	public boolean isRenderComponent() {
		return renderComponent;
	}

	/**
	 * 
	 * @param renderComponent
	 *  the renderComponent to set
	 */
	public void setRenderComponent(boolean renderComponent) {
		this.renderComponent = renderComponent;
	}

	/**
	 * 
	 * @return the disableComponent
	 */
	public boolean isDisableComponent() {
		return disableComponent;
	}

	/**
	 * 
	 * @param disableComponent
	 * the disableComponent to set
	 */
	public void setDisableComponent(boolean disableComponent) {
		this.disableComponent = disableComponent;
	}

	/**
	 * @return the employeeEditableCopy
	 */
	public Employee getEmployeeEditableCopy() {
		return employeeEditableCopy;
	}

	/**
	 * @param employeeEditableCopy
	 *            the employeeEditableCopy to set
	 */
	public void setEmployeeEditableCopy(Employee employeeEditableCopy) {
		this.employeeEditableCopy = employeeEditableCopy;
	}

	/**
	 * @return the image
	 */
	public byte[] getImage() {
		return image;
	}

	/**
	 * @param image
	 *            the image to set
	 */
	public void setImage(byte[] image) {
		this.image = image;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the dropDownSet
	 */
	public List<DropDownList> getDropDownSet() {
		return dropDownSet;
	}

	/**
	 * @param dropDownSet
	 *            the dropDownSet to set
	 */
	public void setDropDownSet(List<DropDownList> dropDownSet) {
		this.dropDownSet = dropDownSet;
	}

	/**
	 * @return the employeeEditable
	 */
	public Employee getEmployeeEditable() {
		return employeeEditable;
	}

	/**
	 * @param employeeEditable
	 *            the employeeEditable to set
	 */
	public void setEmployeeEditable(Employee employeeEditable) {
		this.employeeEditable = employeeEditable;
	}

	/**
	 * @return the upLoadedFile
	 */
	public UploadedFile getUpLoadedFile() {
		return upLoadedFile;
	}

	/**
	 * @param upLoadedFile
	 *            the upLoadedFile to set
	 */
	public void setUpLoadedFile(UploadedFile upLoadedFile) {
		this.upLoadedFile = upLoadedFile;
	}

	/**
	 * @return the managerStatus
	 */
	public boolean isManagerStatus() {
		return managerStatus;
	}

	/**
	 * @param managerStatus
	 *            the managerStatus to set
	 */
	public void setManagerStatus(boolean managerStatus) {
		this.managerStatus = managerStatus;
	}

	/**
	 * @return the employeeService
	 */
	public EmployeeService getEmployeeService() {
		return employeeService;
	}

	/**
	 * @param employeeService
	 *            the employeeService to set
	 */
	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	/**
	 * @return the selectedDesignation
	 */
	public String getSelectedDesignation() {
		return selectedDesignation;
	}

	/**
	 * @param selectedDesignation
	 *            the selectedDesignation to set
	 */
	public void setSelectedDesignation(String selectedDesignation) {
		this.selectedDesignation = selectedDesignation;
	}

	/**
	 * @return the selectedDepartment
	 */
	public String getSelectedDepartment() {
		return selectedDepartment;
	}

	/**
	 * @param selectedDepartment
	 *            the selectedDepartment to set
	 */
	public void setSelectedDepartment(String selectedDepartment) {
		this.selectedDepartment = selectedDepartment;
	}

	/**
	 * @return the selectedReportTo
	 */
	public String getSelectedReportTo() {
		return selectedReportTo;
	}

	/**
	 * @param selectedReportTo
	 *            the selectedReportTo to set
	 */
	public void setSelectedReportTo(String selectedReportTo) {
		this.selectedReportTo = selectedReportTo;
	}

	/**
	 * @return the selectedGender
	 */
	public String getSelectedGender() {
		logger.info("*** getSelectedGender() is called **********");
		return selectedGender;
	}

	/**
	 * @param selectedGender
	 *            the selectedGender to set
	 */
	public void setSelectedGender(String selectedGender) {
		this.selectedGender = selectedGender;
	}

	/**
	 * @return the selectedPrimarySkill
	 */
	public String getSelectedPrimarySkill() {
		return selectedPrimarySkill;
	}

	/**
	 * @param selectedPrimarySkill
	 *            the selectedPrimarySkill to set
	 */
	public void setSelectedPrimarySkill(String selectedPrimarySkill) {
		this.selectedPrimarySkill = selectedPrimarySkill;
	}

	/**
	 * @return the selectedLocation
	 */
	public String getSelectedLocation() {
		return selectedLocation;
	}

	/**
	 * @param selectedLocation
	 *            the selectedLocation to set
	 */
	public void setSelectedLocation(String selectedLocation) {
		this.selectedLocation = selectedLocation;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the designation
	 */
	public Map<String, Object> getDesignation() {
		this.getDropDownList();
		return designation;
	}

	/**
	 * @param designation
	 *            the designation to set
	 */
	public void setDesignation(Map<String, Object> designation) {
		this.designation = designation;
	}

	/**
	 * @return the department
	 */
	public Map<String, Object> getDepartment() {
		return department;
	}

	/**
	 * @param department
	 *            the department to set
	 */
	public void setDepartment(Map<String, Object> department) {
		this.department = department;
	}

	/**
	 * @return the reportTo
	 */
	public Map<String, Object> getReportTo() {
		return reportTo;
	}

	/**
	 * @param reportTo
	 *            the reportTo to set
	 */
	public void setReportTo(Map<String, Object> reportTo) {
		this.reportTo = reportTo;
	}

	/**
	 * @return the gender
	 */
	public Map<String, Object> getGender() {
		return gender;
	}

	/**
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(Map<String, Object> gender) {
		this.gender = gender;
	}

	/**
	 * @return the primarySkill
	 */
	public Map<String, Object> getPrimarySkill() {
		return primarySkill;
	}

	/**
	 * @param primarySkill
	 *            the primarySkill to set
	 */
	public void setPrimarySkill(Map<String, Object> primarySkill) {
		this.primarySkill = primarySkill;
	}

	/**
	 * @return the location
	 */
	public Map<String, Object> getLocation() {
		return location;
	}

	/**
	 * @param location
	 *            the location to set
	 */
	public void setLocation(Map<String, Object> location) {
		this.location = location;
	}

	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @param dateOfBirth
	 *            the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * @return the dateOfJoining
	 */
	public String getDateOfJoining() {
		return dateOfJoining;
	}

	/**
	 * @param dateOfJoining
	 *            the dateOfJoining to set
	 */
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * 
	 * @return the String which indicates the status of employe's enrollment
	 * @throws ParseException
	 * @throws IOException
	 * 
	 * this method maps the employee details that are filled into the backing bean bean object through form of JSF view to the employee
	 * model object .
	 * in turn this model object is passed to the createEmployee() method of employee EmployeeServiceImpl class and expects the
	 * status of employee creation.
	 *
	 *status of employee creation is sent back to the dialogue manager from which this method is invoked to proceed further based on it
	 */
	public String enrollEmployee(){
		String employeeCreationStatus=null;
		try {
		Employee employee = new Employee();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		logger.info("***Details received at enrollEmployee() of backing bean " + this.getId() + "," + this.getName()
				+ "," + this.getSelectedDesignation() + "," + this.getDateOfBirth() + "," + this.getSelectedDepartment()
				+ "," + this.getSelectedReportTo() + "," + this.getSelectedGender() + "," + this.getDateOfJoining()
				+ "," + this.getSelectedPrimarySkill() + "," + this.getStartDate() + "," + this.getEndDate() + ","
				+ this.getSelectedLocation() + "," + this.isManagerStatus() + "," + this.getImage());
		Date dateOfBirth = dateFormat.parse(this.getDateOfBirth());
		Date joinDate = dateFormat.parse(this.getDateOfJoining());
		Date startDate = dateFormat.parse(this.getStartDate());
		if (this.getId() != 0) {
			employee.setId(this.getId());
		}
		employee.setName(this.getName());
		employee.setDesignation(this.getSelectedDesignation());
		employee.setDateOfBirth(dateOfBirth);
		employee.setDepartment(this.getSelectedDepartment());
		employee.setReportTo(this.getSelectedReportTo());
		employee.setGender(this.getSelectedGender());
		employee.setDateOfJoining(joinDate);
		employee.setPrimarySkill(this.getSelectedPrimarySkill());
		employee.setStartDate(startDate);
		if (!(this.getEndDate().isEmpty()) && this.getEndDate() != null) {
			Date endDate = dateFormat.parse(this.getEndDate());
			employee.setEndDate(endDate);
			this.disableEmployeeEditForm();
		}
		employee.setLocation(this.getSelectedLocation());
		if (this.isManagerStatus() == true) {
			employee.setManagerStatus("Yes");
		} else {
			employee.setManagerStatus("No");
		}
		employee.setUploadedImage(this.getImage());
		logger.info("*****Details from model object********* :" + employee.getId() + "," + employee.getName() + ","
				+ employee.getDesignation() + "," + employee.getDateOfBirth() + "," + employee.getDepartment() + ","
				+ employee.getReportTo() + "," + employee.getGender() + "," + employee.getDateOfJoining() + ","
				+ employee.getPrimarySkill() + "," + employee.getStartDate() + "," + employee.getEndDate() + ","
				+ employee.getLocation() + "," + employee.getManagerStatus() + "," + employee.getUploadedImage());
		employeeCreationStatus = employeeService.createEmployee(employee);
		if (employeeCreationStatus.equals(OperationStatus.SUCCESS)) {
			employeeSummary.getEmployeeList();
			this.resetEmployeeDetails();
		}
	
	} catch (NullPointerException nullPointerException) {
		logger.error("NullPointerException Occured", nullPointerException);
	} catch (IOException ioException) {
		logger.error("IOException Occured", ioException);
	} catch (IllegalArgumentException illegalArgumentException) {
		logger.error("IllegalArgumentException Occured", illegalArgumentException);
	} catch (Exception ex) {
		logger.error("Exception Occured ", ex);
	}
		return employeeCreationStatus;
	}

	/**
	 * 
	 * @return the String which indicates the status of file upload
	 * @throws IOException
	 * 
	 * this method assigns the binary data of uploaded file to image property of this managed bean.
	 */
	public String uploadFile() throws IOException {
		logger.info("****Entered into  uploadFile()***");
		logger.info(this.getUpLoadedFile());
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		int fileSize = (int) this.getUpLoadedFile().getSize();
		String fileName = this.getUpLoadedFile().getName();
		this.setUpLoadedFileName(fileName);
		this.setImage(this.getUpLoadedFile().getBytes());
		logger.info("size of the file :" + fileSize + "name of the file is :" + fileName);
		this.changeButtonToLink();
		// Show succes message.
		FacesContext.getCurrentInstance().addMessage("FileUploadForm", new FacesMessage(FacesMessage.SEVERITY_INFO,
				"** " + i18nResourceBundle.getString("app.employee.validation.photo.upload.success") + " **", null));
		logger.info("********Image is sent from uploadeFile() method******");
		ImageServlet.sendImageBytes(this.getImage());
		return OperationStatus.SUCCESS;
	}

	/*
	 * this method is to not render the 'upload Photo' button and render the 'Change Photo' link in JSF view 'employee_enrollment.jsp'
	 * after successful upload of photo
	 */
	public void changeButtonToLink() {
		this.setRenderUploadPhotoButton(false);
		this.setRenderChangePhotoLink(true);
	}

	/**
	 * 
	 * @return String which indicates the status of toggling of both button and hyper link.
	 */
	public String changeLinkToButton() {
		this.setRenderChangePhotoLink(false);
		this.setRenderUploadPhotoButton(true);
		return OperationStatus.SUCCESS;
	}

	/**
	 * this method retrieves the list of drop down values
	 */
	public void getDropDownList() {
		try {
		this.setDropDownSet(employeeService.getDropDownList());
		this.distributeDropDownlist();
	} catch (NullPointerException nullPointerException) {
		logger.error("NullPointerException is raised", nullPointerException);
	} catch (IOException ioException) {
		logger.error("IOException Occured", ioException);
	} catch (IllegalArgumentException illegalArgumentException) {
		logger.error("IllegalArgumentException Occured", illegalArgumentException);
	} catch (Exception exception) {
		logger.error("Exception is raised ", exception);
	}
	}

	/**
	 * this method distributes the list drop down values retrieved from DB to corresponding drop down component in JSF view. 
	 */
	public void distributeDropDownlist() {
		logger.info("Drop Down List from  DB is :");
		Map<String, Object> reportingList = new LinkedHashMap<String, Object>();
		Map<String, Object> locationList = new LinkedHashMap<String, Object>();
		Map<String, Object> designationList = new LinkedHashMap<String, Object>();
		Map<String, Object> departmentList = new LinkedHashMap<String, Object>();
		Map<String, Object> primarySkillList = new LinkedHashMap<String, Object>();
		for (DropDownList dropDownItem : this.getDropDownSet()) {
			logger.info(dropDownItem.getItemId() + "," + dropDownItem.getItemLabel() + ","
					+ dropDownItem.getItemCategory());
			if (dropDownItem.getItemCategory().equalsIgnoreCase("reporting to")) {
				reportingList.put(dropDownItem.getItemLabel(), String.valueOf(dropDownItem.getItemId()));
				this.setReportTo(reportingList);
			} else if (dropDownItem.getItemCategory().equalsIgnoreCase("location")) {
				locationList.put(dropDownItem.getItemLabel(), String.valueOf(dropDownItem.getItemId()));
				this.setLocation(locationList);
			} else if (dropDownItem.getItemCategory().equalsIgnoreCase("designation")) {
				designationList.put(dropDownItem.getItemLabel(), String.valueOf(dropDownItem.getItemId()));
				this.setDesignation(designationList);
			}
			else if (dropDownItem.getItemCategory().equalsIgnoreCase("department")) {
				departmentList.put(dropDownItem.getItemLabel(), String.valueOf(dropDownItem.getItemId()));
				this.setDepartment(departmentList);
			}
			else if (dropDownItem.getItemCategory().equalsIgnoreCase("primary skill")) {
				primarySkillList.put(dropDownItem.getItemLabel(), String.valueOf(dropDownItem.getItemId()));
				this.setPrimarySkill(primarySkillList);
			}
		}
	}

	
	/**
	 * this method is to enable the employee edit form if employee is active ( if end date is not entered)
	 */
	public void enableEmployeEditForm() {
		this.setRenderComponent(true);
		this.setDisableComponent(false);
	}

	/**
	 * this method is to disable the employee edit form if employee is inactive ( if end date is entered)
	 */
	public void disableEmployeeEditForm() {
		this.setRenderComponent(false);
		this.setDisableComponent(true);
	}

	/**
	 * 
	 * @param employee which contains the details of employee to show them in employee edit form. 
	 * @return the String . this represents status of setting employee details to edit form.
	 */
	public String setEmployee(Employee employee) {
		logger.info("*************Entered into setEmployee() method*************");
		if (employee.getEndDateS() != null) {
			this.disableEmployeeEditForm();
		} else {
			this.enableEmployeEditForm();
		}
		this.setEmployeeEditable(employee);
		this.setImage(this.getEmployeeEditable().getUploadedImage());
		logger.info("*****Immage is sent from setEmployee() ************* ");
		ImageServlet.sendImageBytes(this.getImage());
		logger.info("**********Employee editable drop down details *********"
				+ this.getEmployeeEditable().getDesignation() + "," + this.getEmployeeEditable().getDepartment() + ","
				+ this.getEmployeeEditable().getLocation() + "," + this.getEmployeeEditable().getPrimarySkill() + ","
				+ this.getEmployeeEditable().getReportTo());
		this.changeLableToId();
		logger.info("**********Employee editable drop down details *********"
				+ this.getEmployeeEditable().getDesignation() + "," + this.getEmployeeEditable().getDepartment() + ","
				+ this.getEmployeeEditable().getLocation() + "," + this.getEmployeeEditable().getPrimarySkill() + ","
				+ this.getEmployeeEditable().getReportTo());
		this.employeeEditableBackup();
		return OperationStatus.SUCCESS;
	}

	/**
	 * 
	 * this method is to convert the Label values into corresponding id's as well as String type dates to Date type dates
	 * to store them in DB accordingly .
	 * 
	 * and also mapping manager status to 'Yes' or 'No' based on the check box value 'true' or 'false'
	 */
	public void changeLableToId() {
		logger.info("********* I am called by setEmployee() ****");
		try {
		for (DropDownList dropDownItem : employeeService.getDropDownList()) {
			logger.info("Drop Down item is:" + dropDownItem.getItemId() + "," + dropDownItem.getItemLabel() + ","
					+ dropDownItem.getItemCategory());
			if (dropDownItem.getItemLabel().equals(this.getEmployeeEditable().getDesignation())) {
				this.getEmployeeEditable().setDesignation(String.valueOf(dropDownItem.getItemId()));
			} else if (dropDownItem.getItemLabel().equals(this.getEmployeeEditable().getDepartment())) {
				this.getEmployeeEditable().setDepartment(String.valueOf(dropDownItem.getItemId()));
			} else if (dropDownItem.getItemLabel().equals(this.getEmployeeEditable().getReportTo())) {
				this.getEmployeeEditable().setReportTo(String.valueOf(dropDownItem.getItemId()));
				;
			} else if (dropDownItem.getItemLabel().equals(this.getEmployeeEditable().getPrimarySkill())) {
				this.getEmployeeEditable().setPrimarySkill(String.valueOf(dropDownItem.getItemId()));
				;
			} else if (dropDownItem.getItemLabel().equals(this.getEmployeeEditable().getLocation())) {
				this.getEmployeeEditable().setLocation(String.valueOf(dropDownItem.getItemId()));
				;
			}
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		this.getEmployeeEditable().setDateOfBirthS(dateFormat.format(this.getEmployeeEditable().getDateOfBirth()));
		this.getEmployeeEditable().setDateOfJoiningS(dateFormat.format(this.getEmployeeEditable().getDateOfJoining()));
		this.getEmployeeEditable().setStartDateS(dateFormat.format(this.getEmployeeEditable().getStartDate()));
		if (this.getEmployeeEditable().getEndDate() != null) {
			this.getEmployeeEditable().setEndDateS(dateFormat.format(this.getEmployeeEditable().getEndDate()));
		}
		if (this.getEmployeeEditable().getManagerStatus().equalsIgnoreCase("yes")) {
			this.getEmployeeEditable().setManagerStatusB(true);
		} else {
			this.getEmployeeEditable().setManagerStatusB(false);
		}
		} catch (NullPointerException nullPointerException) {
			logger.error("NullPointerException is raised", nullPointerException);
		} catch (IOException ioException) {
			logger.error("IOException Occured", ioException);
		} catch (IllegalArgumentException illegalArgumentException) {
			logger.error("IllegalArgumentException Occured", illegalArgumentException);
		} catch (Exception exception) {
			logger.error("Exception is raised ", exception);
		}
	}

	
	/**
	 * this method is to take the back up of employee details that's been displayed in employee edit form. 
	 * these details are in turn used to restore edit form as part of reset functionality.
	 */
	public void employeeEditableBackup() {
		this.getEmployeeEditableCopy().setName(this.getEmployeeEditable().getName());
		this.getEmployeeEditableCopy().setDesignation(this.getEmployeeEditable().getDesignation());
		this.getEmployeeEditableCopy().setDateOfBirthS(this.getEmployeeEditable().getDateOfBirthS());
		this.getEmployeeEditableCopy().setDepartment(this.getEmployeeEditable().getDepartment());
		this.getEmployeeEditableCopy().setReportTo(this.getEmployeeEditable().getReportTo());
		this.getEmployeeEditableCopy().setGender(this.getEmployeeEditable().getGender());
		this.getEmployeeEditableCopy().setDateOfJoiningS(this.getEmployeeEditable().getDateOfJoiningS());
		this.getEmployeeEditableCopy().setPrimarySkill(this.getEmployeeEditable().getPrimarySkill());
		this.getEmployeeEditableCopy().setStartDateS(this.getEmployeeEditable().getStartDateS());
		if (this.getEmployeeEditable().getEndDateS() != null) {
			this.getEmployeeEditableCopy().setEndDateS(this.getEmployeeEditable().getEndDateS());
		}
		this.getEmployeeEditableCopy().setLocation(this.getEmployeeEditable().getLocation());
		this.getEmployeeEditableCopy().setManagerStatusB(this.getEmployeeEditable().isManagerStatusB());
		this.getEmployeeEditable().setUploadedImage(this.getEmployeeEditable().getUploadedImage());
	}

	/**
	 * 
	 * @return the String which indicates the status of update of employee
	 * @throws ParseException
	 * @throws IOException
	 * 
	 * this method maps the employee's updated details to corresponding properties of this backing bean to save them in DB
	 * by calling the same service which is used for enrollment .
	 */
	public String updateEmployee() throws ParseException, IOException {
		logger.info("******* Entered into update Employee method of backing bean *****");
		this.id = this.getEmployeeEditable().getId();
		this.name = this.getEmployeeEditable().getName();
		this.selectedDesignation = this.getEmployeeEditable().getDesignation();
		this.dateOfBirth = this.getEmployeeEditable().getDateOfBirthS();
		this.selectedDepartment = this.getEmployeeEditable().getDepartment();
		this.setSelectedReportTo(this.getEmployeeEditable().getReportTo());
		this.setSelectedGender(this.getEmployeeEditable().getGender());
		this.setDateOfJoining(this.getEmployeeEditable().getDateOfJoiningS());
		this.setSelectedPrimarySkill(this.getEmployeeEditable().getPrimarySkill());
		this.setStartDate(this.getEmployeeEditable().getStartDateS());
		if (this.getEmployeeEditable().getEndDateS() != null) {
			this.setEndDate(this.getEmployeeEditable().getEndDateS());
		}
		this.setSelectedLocation(this.getEmployeeEditable().getLocation());
		this.setManagerStatus(this.getEmployeeEditable().isManagerStatusB());
		logger.info("***EmployeeDetails to be updated from  updateEmployee() method ********** " + this.getId() + ","
				+ this.getName() + "," + this.getSelectedDesignation() + "," + this.getDateOfBirth() + ","
				+ this.getSelectedDepartment() + "," + this.getSelectedReportTo() + "," + this.getSelectedGender() + ","
				+ this.getDateOfJoining() + "," + this.getSelectedPrimarySkill() + "," + this.getStartDate() + ","
				+ this.getEndDate() + "," + this.getSelectedLocation() + "," + this.isManagerStatus() + ","
				+ this.getImage());
		logger.info("******* Calling the enrollEmployee() method of backing bean **************");
		String employeeUpdateStatus = this.enrollEmployee();
		if (employeeUpdateStatus.equalsIgnoreCase("success")) {
			if (this.getEmployeeEditable().getUploadedImage() != null) {
				ImageServlet.sendImageBytes(this.getEmployeeEditable().getUploadedImage());
			} else if (this.getUpLoadedFile() != null) {
				ImageServlet.sendImageBytes(this.getUpLoadedFile().getBytes());
			}
		}
		return employeeUpdateStatus;
	}

	/**
	 * 
	 * @return String which indicates the reset of employee details
	 * 
	 * this method is to nullifying the values of backing bean properties which are bound to JSF view.
	 */
	public String resetEmployeeDetails() {
		this.changeLinkToButton();
		if (employeeSummary != null) {
			employeeSummary.getEmployeeList();
		}
		logger.info("****** restEmployeeDetails() is called *********");
		this.id = 0;
		this.name = null;
		this.selectedDesignation = null;
		this.dateOfBirth = null;
		this.selectedDepartment = null;
		this.selectedReportTo = null;
		this.selectedGender = "Others";
		this.dateOfJoining = null;
		this.selectedPrimarySkill = null;
		this.startDate = null;
		;
		this.endDate = null;
		this.selectedLocation = null;
		this.managerStatus = false;
		this.setImage(null);
		logger.info("******** setting image servlet to null from resetEmployeeDetails() *****");
		ImageServlet.sendImageBytes(null);
		logger.info("*** done *******");
		return OperationStatus.SUCCESS;
	}

	/**
	 * 
	 * @return String indicates the status of reset of employee edit form
	 * 
	 * this method is to restore the employee edit form as part of reset functionality.
	 */
	public String resetEditableEmployeeDetails() {
		this.getEmployeeEditable().setName(this.getEmployeeEditableCopy().getName());
		this.getEmployeeEditable().setDesignation(this.getEmployeeEditableCopy().getDesignation());
		this.getEmployeeEditable().setDateOfBirthS(this.getEmployeeEditableCopy().getDateOfBirthS());
		this.getEmployeeEditable().setDepartment(this.getEmployeeEditableCopy().getDepartment());
		this.getEmployeeEditable().setReportTo(this.getEmployeeEditableCopy().getReportTo());
		this.getEmployeeEditable().setGender(this.getEmployeeEditableCopy().getGender());
		this.getEmployeeEditable().setDateOfJoiningS(this.getEmployeeEditableCopy().getDateOfJoiningS());
		this.getEmployeeEditable().setPrimarySkill(this.getEmployeeEditableCopy().getPrimarySkill());
		this.getEmployeeEditable().setStartDateS(this.getEmployeeEditableCopy().getStartDateS());
		if (this.getEmployeeEditableCopy().getEndDateS() != null) {
			this.getEmployeeEditable().setEndDateS(this.getEmployeeEditableCopy().getEndDateS());
		}
		this.getEmployeeEditable().setLocation(this.getEmployeeEditableCopy().getLocation());
		this.getEmployeeEditable().setManagerStatusB(this.getEmployeeEditableCopy().isManagerStatusB());
		ImageServlet.sendImageBytes(this.getEmployeeEditable().getUploadedImage());
		return OperationStatus.SUCCESS;
	}

	/**
	 * 
	 * @param employeeSummaryReceived
	 */
	public static void sendEmployeeSummaryObject(EmployeeSummary employeeSummaryReceived) {
		logger.info("*** Employee summary object is received *** " + employeeSummaryReceived);
		employeeSummary = employeeSummaryReceived;
	}
}
