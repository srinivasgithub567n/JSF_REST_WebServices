package com.jsf.shale.validators;

import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import org.apache.log4j.Logger;

/**
 * s
 * @author EI11321
 *
 */
public class DepartmentValidator implements Validator {
	private static final Logger logger = Logger.getLogger(DepartmentValidator.class);

	/**
	 * this method is responsible of checking whether one of the departments from the drop down is selected or not. if not 
	 * 
	 * validation error is thrown back.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String department = (String) value;
		if (department.equals("-1")) {
			logger.info("********* Entered into if block of -1 condition ******** ");
			FacesMessage message = new FacesMessage();
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.department.required"));
			throw new ValidatorException(message);
		}
	}
}
