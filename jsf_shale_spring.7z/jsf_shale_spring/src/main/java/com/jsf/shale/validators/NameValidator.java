package com.jsf.shale.validators;

import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import org.apache.log4j.Logger;

/**
 * 
 * @author EI11321
 *
 */
public class NameValidator implements Validator {
	private static final Logger logger = Logger.getLogger(NameValidator.class);

	/**
	 * this method applies validation on Name of employee.
	 * here Name should not start with space and  should not contain digits .
	 * if above 2 conditions are not matched then validation error is thrown back.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		logger.info("************** Entered into name validator method *********");
		String enteredName = (String) value;
		FacesMessage message = new FacesMessage();
		if (enteredName.length() > 40) {
			message.setSummary("name should not exceed 40 characters");
			throw new ValidatorException(message);
		} else {
			logger.info("****Enter name is :" + enteredName);
			Pattern pattern = Pattern.compile("[a-zA-Z]{1}[a-zA-Z ]*");
			Matcher match = pattern.matcher(enteredName);
			boolean matchFound = match.matches();
			logger.info("Match  found value :" + matchFound);
			if (!matchFound) {
				logger.info("**** Entered into if block to display validation message***********");
				if (enteredName.charAt(0) == ' ')
					message.setSummary(i18nResourceBundle.getString("app.employee.validation.name.space"));
				else
					message.setSummary(i18nResourceBundle.getString("app.employee.validation.name.onlyalphabets"));
				logger.info("************** about to throw and validation exception *******");
				throw new ValidatorException(message);
			}
		}
	}
}
