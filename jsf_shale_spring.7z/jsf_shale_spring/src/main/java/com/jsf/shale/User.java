package com.jsf.shale;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.html.HtmlDataTable;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import org.apache.log4j.Logger;
import com.jsf.shale.model.UserInfo;
import com.jsf.shale.service.RegistrationService;
import com.jsf.shale.util.DTOComparator;
import com.jsf.shale.util.OperationStatus;
import com.jsf.shale.util.SessionContext;

/**
 * 
 * @author srinivasa.nayana
 * 
 *         Managed bean which is bound to registration JSP page
 *
 */
public class User {
	private static final Logger logger = Logger.getLogger(User.class);
	private int id;
	private String firstName;
	private String lastName;
	private String emailId;
	private Long mobileNo;
	private String password;
	private RegistrationService registrationService;
	private List<UserInfo> customerList;
	private boolean editable;
	private UserInfo userEditable = new UserInfo();
	private Map<Long, Boolean> selectedIds = new HashMap<Long, Boolean>();
	private List<UserInfo> selectedDataList;
	private String sortField = null;
	private boolean sortAscending = true;
	private String searchKey;
	private int selectedCheckboxCount;

	public int getSelectedCheckboxCount() {
		logger.info("Entered into getSelectedCheckboxCount()");
		int count = this.getSelectedIds().size();
		logger.info("Selected ids count from getSelectedCheckboxCount()  is :" + count);
		return count;
	}

	public void setSelectedCheckboxCount(int selectedCheckboxCount) {
		this.selectedCheckboxCount = selectedCheckboxCount;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSearchKey() {
		return searchKey;
	}

	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}

	public String getSortField() {
		return sortField;
	}

	public void setSortField(String sortField) {
		this.sortField = sortField;
	}

	public boolean isSortAscending() {
		return sortAscending;
	}

	public void setSortAscending(boolean sortAscending) {
		this.sortAscending = sortAscending;
	}

	public UserInfo getUserEditable() {
		return userEditable;
	}

	public void setUserEditable(UserInfo userEditable) {
		this.userEditable = userEditable;
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public List<UserInfo> getCustomerList() {
		if (this.customerList == null) {
			this.loadCustomersList();
		}
		return customerList;
	}

	public void setCustomerList(List<UserInfo> cusotmerList) {
		this.customerList = cusotmerList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public RegistrationService getRegistrationService() {
		return registrationService;
	}

	public void setRegistrationService(RegistrationService registrationService) {
		this.registrationService = registrationService;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Map<Long, Boolean> getSelectedIds() {
		logger.info("Entered into getSelectedIds()");
		logger.info("selected ids size :" + selectedIds.size());
		return selectedIds;
	}

	public void setSelectedIds(Map<Long, Boolean> selectedIds) {
		logger.info("Entered into setSelectedIds()");
		this.selectedIds = selectedIds;
	}

	public List<UserInfo> getSelectedDataList() {
		return selectedDataList;
	}

	public void setSelectedDataList(List<UserInfo> selectedDataList) {
		this.selectedDataList = selectedDataList;
	}

	/**
	 * 
	 * @return String which represent the status of customer deletion
	 * 
	 *         this method is used to pass the customers list that need to be
	 *         deleted to the method of RegistrationService class
	 */
	public String deleteSelectedCustomers() {
		logger.info("Entered into deleteSelectedCustomers() method of User managed bean");
		logger.info("User selected rows to delete : " + this.getSelectedIds());
		selectedDataList = new ArrayList<UserInfo>();
		String userDeletionStatus = OperationStatus.NOT_SELECTED_CHECKBOX;
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		for (UserInfo dataItem : customerList) {
			if (selectedIds.get(dataItem.getId()) != null) {
				if (selectedIds.get(dataItem.getId()).booleanValue()) {
					selectedDataList.add(dataItem);
					selectedIds.remove(dataItem.getId());
				}
			}
		}
		logger.info("Final users list to be deleted : " + this.getSelectedDataList());
		if (this.getSelectedDataList().size() > 0) {
			int[] ids = new int[selectedDataList.size()];
			for (int i = 0; i < ids.length; i++) {
				ids[i] = selectedDataList.get(i).getId();
			}
			logger.info("Final user id's to be deleted : " + ids);
			userDeletionStatus = registrationService.deleteSelectedCustomers(ids);
			logger.info("Multiple users deletion status from service layer of JSF :" + userDeletionStatus);
			if (userDeletionStatus.equals(OperationStatus.SUCCESS)) {
				this.loadCustomersList();
				context.addMessage(null, new FacesMessage(i18nResourceBundle.getString("method.deletemutiple.info")));
			}
			return userDeletionStatus;
		} else {
			logger.info("Multiple users deletion status from service layer of JSF :" + userDeletionStatus);
			context.addMessage(null,
					new FacesMessage(i18nResourceBundle.getString("method.deletemutiple.not.selected")));
			return userDeletionStatus;
		}
	}

	/**
	 * 
	 * @return String which represents the status of user creation this method
	 *         passes the user details who registered newly to the method of
	 *         RegistrationService class.
	 */
	public String addUser() {
		logger.info("Entered into addUser() method of User managed bean");
		UserInfo userInfo = new UserInfo();
		userInfo.setEmailId(this.getEmailId());
		userInfo.setMobileNo(this.getMobileNo());
		userInfo.setFirstName(this.getFirstName());
		userInfo.setLastName(this.getLastName());
		userInfo.setPassword(this.getPassword());
		logger.info("Details of user to be added : " + userInfo);
		String userCreationStatus = registrationService.addUser(userInfo);
		logger.info("status of user addition from serive layer of JSF : " + userCreationStatus);
		if (userCreationStatus != null && userCreationStatus.equals(OperationStatus.SUCCESS)) {
			this.resetRegistrationForm();
		}
		return userCreationStatus;
	}

	public void resetRegistrationForm() {
		this.setFirstName(null);
		this.setLastName(null);
		this.setEmailId(null);
		this.setMobileNo(null);
	}

	/**
	 * 
	 * @return String which indicates the status of user updation this method passes
	 *         the details of user who needs to be updated to the method of
	 *         RegistrationService class
	 */
	public String updateCustomer() {
		logger.info("Entered into updateCustomer() method of User managed bean");
		logger.info("Details of user to be updated :" + this.getUserEditable());
		String userUpdationStatus = registrationService.updateCustomer(this.getUserEditable());
		logger.info("status of user updation from service layer of JSF : " + userUpdationStatus);
		if (userUpdationStatus.equals(OperationStatus.SUCCESS)) {
			this.loadCustomersList();
			SessionContext.getInstance().getCurrentSessionn().setAttribute("user",
					this.getUserEditable().getFirstName() + " " + this.getUserEditable().getLastName());
			logger.info("Updated list of users :" + this.getCustomerList());
		}
		return userUpdationStatus;
	}

	/**
	 * 
	 * @param userInfo
	 *            of UserInfo is accepted to set the userEditable property
	 * @return String represents the status of setting the value.
	 */
	public String editMode(UserInfo userInfo) {
		this.setUserEditable(userInfo);
		return OperationStatus.SUCCESS;
	}

	/**
	 * 
	 * @param userInfo
	 *            is accepted which indicates the user to be deleted.
	 * @return String which represents the status of user deletion
	 */
	public String deleteCustomer(UserInfo userInfo) {
		logger.info("Entered into deleteCustomer() method of 'User' managed bean");
		logger.info("Details of the user to be deleted : " + userInfo);
		String usersDeletionstatus = registrationService.deleteCustomer(userInfo);
		logger.info("status of user deletion :" + usersDeletionstatus);
		if (usersDeletionstatus.equals(OperationStatus.SUCCESS)) {
			this.loadCustomersList();
		}
		return usersDeletionstatus;
	}

	/*** Pagination code ***/
	HtmlDataTable dataTable = new HtmlDataTable();

	// to get to the first page of pagination
	public void pageFirst() {
		dataTable.setFirst(0);
	}

	// to get to the previous page of pagination
	public void pagePrevious() {
		dataTable.setFirst(dataTable.getFirst() - dataTable.getRows());
	}

	// to get to the next page of pagination
	public void pageNext() {
		dataTable.setFirst(dataTable.getFirst() + dataTable.getRows());
	}

	// to get to the last page of pagination
	public void pageLast() {
		int count = dataTable.getRowCount();
		int rows = dataTable.getRows();
		dataTable.setFirst(count - ((count % rows != 0) ? count % rows : rows));
	}

	// to get the current page number
	public int getCurrentPage() {
		int rows = dataTable.getRows();
		int first = dataTable.getFirst();
		int count = dataTable.getRowCount();
		return (count / rows) - ((count - first) / rows) + 1;
	}

	// to get the total no of pages
	public int getTotalPages() {
		int rows = dataTable.getRows();
		int count = dataTable.getRowCount();
		return (count / rows) + ((count % rows != 0) ? 1 : 0);
	}

	public HtmlDataTable getDataTable() {
		return dataTable;
	}

	public void setDataTable(HtmlDataTable dataTable) {
		this.dataTable = dataTable;
	}

	/**
	 * 
	 * @param event
	 *            this method is used to sort the data table based on the field that
	 *            user wants
	 */
	public void sortDataList(ActionEvent event) {
		logger.info("Entered into sortDataList() method of 'User' managed bean");
		String sortFieldAttribute = getAttribute(event, "sortField");
		logger.info("Sorting field chosen based on which data needs to be sorted  :" + sortFieldAttribute);
		// Get and set sort field and sort order.
		if (sortField != null && sortField.equals(sortFieldAttribute)) {
			sortAscending = !sortAscending;
		} else {
			sortField = sortFieldAttribute;
			sortAscending = true;
		}
		logger.info("Users list before sorting :" + this.getCustomerList());
		// Sort results.
		if (sortField != null) {
			Collections.sort(this.getCustomerList(), new DTOComparator(sortField, sortAscending));
		}
		logger.info("Users list after sorting :" + this.getCustomerList());
	}

	/**
	 * to get the sorting field attribute value that's been passed as part of event
	 * 
	 * @param event
	 * @param name
	 * @return String of sorting filed based on which sorting needs to be done
	 */
	private static String getAttribute(ActionEvent event, String name) {
		String value = (String) event.getComponent().getAttributes().get(name);
		return value;
	}

	/**
	 * this is to retrieve the list of users and set it to the property customerList
	 */
	public void loadCustomersList() {
		this.customerList = registrationService.getCustomers();
	}

	/**
	 * 
	 * @return String which represents the status of data availability
	 */
	public String checkDataAvailability() {
		String usersExistenceStatus = OperationStatus.SUCCESS;
		this.loadCustomersList();
		if (this.getCustomerList() == null) {
			usersExistenceStatus = OperationStatus.NO_DATA;
		}
		return usersExistenceStatus;
	}

	/**
	 * 
	 * this method is used to filter(search) the table rows based on the search key
	 * passed by user
	 */
	public void filterRows() {
		logger.info("Entered into filterRows() method of 'User' managed bean");
		List<UserInfo> tempList = new ArrayList<UserInfo>();
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle msg = context.getApplication().getResourceBundle(context, "msg");
		for (UserInfo user : this.getCustomerList()) {
			if (Integer.toString(user.getId()).indexOf(this.getSearchKey()) != -1
					|| user.getFirstName().indexOf(this.getSearchKey()) != -1
					|| user.getLastName().indexOf(this.getSearchKey()) != -1
					|| user.getEmailId().indexOf(this.getSearchKey()) != -1
					|| Long.toString(user.getMobileNo()).indexOf(this.getSearchKey()) != -1) {
				tempList.add(user);
			}
		}
		logger.info("Number of matching rows found :" + tempList.size());
		if (tempList.size() > 0) {
			this.setCustomerList(tempList);
		} else {
			context.addMessage(null, new FacesMessage(msg.getString("app.userslist.search.notfound")));
		}
		this.setSearchKey(null);
	}
}
