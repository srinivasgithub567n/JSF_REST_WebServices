package com.jsf.shale.validators;

import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import org.apache.log4j.Logger;

/**
 * 
 * @author EI11321
 *
 */
public class StartDateValidator implements Validator {
	private static final Logger logger = Logger.getLogger(StartDateValidator.class);
	public static String dateOfJoining;
	FacesMessage message = new FacesMessage();

	/**
	 * this method applies validation on start date where as start date is compared with date of joining and 
	 * if start date is not equal or after date of joining , validation error is thrown back.
	 */
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String startDate = (String) value;
		EndDateValidator.sendStartdate(startDate);
		logger.info("*******Entered start date is :" + startDate);
		int startDateDay = 0;
		int startDateMonth = 0;
		int startDateYear = 0;
		int dateOfJoiningDate = 0;
		int dateOfJoiningMonth = 0;
		int dateOfJoiningYear = 0;
		String[] startDateArray = startDate.split("-");
		if (startDateArray.length == 3 && !(startDateArray[0].isEmpty()) && !(startDateArray[1].isEmpty())
				&& !(startDateArray[2].isEmpty())) {
			startDateDay = Integer.parseInt(startDateArray[0]);
			startDateMonth = Integer.parseInt(startDateArray[1]);
			startDateYear = Integer.parseInt(startDateArray[2]);
		}
		String[] dateOfJoiningArray = dateOfJoining.split("-");
		if (dateOfJoiningArray.length == 3 && !(dateOfJoiningArray[0].isEmpty()) && !(dateOfJoiningArray[1].isEmpty())
				&& !(dateOfJoiningArray[2].isEmpty())) {
			dateOfJoiningDate = Integer.parseInt(dateOfJoiningArray[0]);
			dateOfJoiningMonth = Integer.parseInt(dateOfJoiningArray[1]);
			dateOfJoiningYear = Integer.parseInt(dateOfJoiningArray[2]);
		}
		logger.info(" **** Day , Month and Year of start date are :" + startDateDay + "," + startDateMonth + ","
				+ startDateYear);
		logger.info(" **** Day , Month and Year of DateOfJoining are  :" + dateOfJoiningDate + "," + dateOfJoiningMonth
				+ "," + dateOfJoiningYear);
		if (startDateYear >= dateOfJoiningYear) {
			if (startDateYear == dateOfJoiningYear) {
				if (startDateMonth >= dateOfJoiningMonth) {
					if (startDateMonth == dateOfJoiningMonth) {
						if (startDateDay < dateOfJoiningDate) {
							message.setSummary(
									i18nResourceBundle.getString("app.employee.validation.startdate.validity"));
							throw new ValidatorException(message);
						}
					}
				} else {
					message.setSummary(i18nResourceBundle.getString("app.employee.validation.startdate.validity"));
					throw new ValidatorException(message);
				}
			}
		} else {
			message.setSummary(i18nResourceBundle.getString("app.employee.validation.startdate.validity"));
			throw new ValidatorException(message);
		}
	}

	//static method to get the value of date of joining to cross verify with start date
	public static void sendDateOfJoining(String dateOfJoiningReceived) {
		dateOfJoining = dateOfJoiningReceived;
	}
}
