package com.jsf.shale.service;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jsf.shale.model.DropDownList;
import com.jsf.shale.model.Employee;
import com.jsf.shale.util.OperationStatus;

/**
 * 
 * @author EI11321
 * 
 *   this class contains the employee related operations.
 *
 */
public class EmployeeServiceImpl implements EmployeeService {
	private static final Logger logger = Logger.getLogger(EmployeeServiceImpl.class);

	/**
	 * @param employee
	 * @return String which indicates the employee create/update status.
	 * 
	 * this method converts the details of the employee object into string values of JSON object to consume the web service
	 * 
	 * this JSON object is sent to REST web service as JSON request .
	 * 
	 * corresponding message is sent to JSF view based no the status code and message retrieved from web service as a response.
	 * @throws IOException, SQLException 
	 * @throws ClientProtocolException 
	 * 
	 */
	public String createEmployee(Employee employee) throws ClientProtocolException, IOException, SQLException {
		String userCreationStatus = null;
		
			if (employee != null) {
				logger.info("Details from JSF employee service create Employee method  :" + employee.getId() + ","
						+ employee.getName() + "," + employee.getDesignation() + "," + employee.getDateOfBirth() + ","
						+ employee.getDepartment() + "," + employee.getReportTo() + "," + employee.getGender() + ","
						+ employee.getDateOfJoining() + "," + employee.getPrimarySkill() + "," + employee.getStartDate()
						+ "," + employee.getEndDate() + "," + employee.getLocation() + "," + employee.getManagerStatus()
						+ "," + employee.getUploadedImage());
				String url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/employee";
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				String dateOfBirth = dateFormat.format(employee.getDateOfBirth());
				String dateOfJoining = dateFormat.format(employee.getDateOfJoining());
				String startDate = dateFormat.format(employee.getStartDate());
				JSONObject json = new JSONObject();
				if (employee.getId() != 0) {
					logger.info("*** employee update web service url is called *******");
					url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/employee/" + employee.getId();
					json.put("id", employee.getId());
				}
				json.put("name", employee.getName());
				json.put("designation", employee.getDesignation());
				json.put("dateOfBirth", dateOfBirth);
				json.put("department", employee.getDepartment());
				json.put("reportTo", employee.getReportTo());
				json.put("gender", employee.getGender());
				json.put("dateOfJoining", dateOfJoining);
				json.put("primarySkill", employee.getPrimarySkill());
				json.put("startDate", startDate);
				if (employee.getEndDate() != null) {
					String endDate = dateFormat.format(employee.getEndDate());
					json.put("endDate", endDate);
				}
				json.put("location", employee.getLocation());
				json.put("managerStatus", employee.getManagerStatus());
				if (employee.getUploadedImage() != null) {
					byte[] encodedImage = Base64.encodeBase64(employee.getUploadedImage());
					json.put("uploadedImage", encodedImage);
				}
				CloseableHttpClient httpClient = HttpClients.createDefault();
				HttpPost httpRequest = new HttpPost(url);
				StringEntity params = new StringEntity(json.toString(), "UTF-8");
				logger.info("User Details to be added in JSON format :" + params);
				httpRequest.addHeader("content-type", "application/json;charset=UTF-8");
				httpRequest.addHeader("charset", "UTF-8");
				httpRequest.setEntity(params);
				HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
				logger.info("Http Response is :" + httpResponse.toString());
				int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
				logger.info("Http status code is :" + httpStatusCode);
				String httpResponseBody = EntityUtils.toString(httpResponse.getEntity());
				FacesContext context = FacesContext.getCurrentInstance();
				ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
				if (httpStatusCode == 200 && httpResponseBody.equals(OperationStatus.SUCCESS)) {
					userCreationStatus = httpResponseBody;
					if (employee.getId() == 0) {
						context.addMessage("panel-container", new FacesMessage(FacesMessage.SEVERITY_INFO,
								"*** " + i18nResourceBundle.getString("app.employee.createorupdate.msg.prefix") + " : '"
										+ employee.getName() + "'  "
										+ i18nResourceBundle.getString("app.employee.create.msg.suffix") + " ***",
								null));
					} else {
						context.addMessage("panel-container", new FacesMessage(FacesMessage.SEVERITY_INFO,
								"*** " + i18nResourceBundle.getString("app.employee.createorupdate.msg.prefix") + " : '"
										+ employee.getName() + "' "
										+ i18nResourceBundle.getString("app.employee.update.msg.suffix") + " ***",
								null));
					}
				} else if (httpStatusCode == 500) {
					userCreationStatus = OperationStatus.FAILURE;
					context.addMessage("panel-container",
							new FacesMessage(FacesMessage.SEVERITY_ERROR, "*** "
									+ i18nResourceBundle.getString("app.employee.createorupdate.failure") + " ***",
									null));
				} else if (httpStatusCode == 409) {
					userCreationStatus = OperationStatus.FAILURE;
					context.addMessage("panel-container",
							new FacesMessage(FacesMessage.SEVERITY_ERROR,
									"*** " + i18nResourceBundle
											.getString("app.employee.update.error.inactiveemployee.update") + " ***",
									null));
				}
			} else {
				throw new NullPointerException("Employee details are not passed to create");
			}
		
		return userCreationStatus;
	}

	
	/**
	 * 
	 * @return List<DropDownList>  which represents the list drop down items.
	 * 
	 * this method consumes RESTFul web service to get the list of drop down items.
	 * @throws IOException, SQLException 
	 * @throws ParseException 
	 */
	
	public List<DropDownList> getDropDownList() throws ParseException, IOException, SQLException {
		logger.info("Entered into getDropDownList() method");
		List<DropDownList> dropDownList = null;
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/dropDownList";
			CloseableHttpClient httpClient = HttpClients.createDefault();
			HttpGet httpRequest = new HttpGet(url);
			httpRequest.addHeader("content-type", "application/json;charset=UTF-8");
			httpRequest.addHeader("charset", "UTF-8");
			HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
			int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
			logger.info("Http Response is : " + httpResponse);
			logger.info("Http status code is :" + httpStatusCode);
			if (httpStatusCode == 200) {
				HttpEntity entity = httpResponse.getEntity();
				logger.info("Http Response Body is :" + entity);
				String jsonResponse = EntityUtils.toString(entity);
				logger.info("Http Response body in JSON format :" + jsonResponse);
				ObjectMapper mapper = new ObjectMapper();
				dropDownList = mapper.readValue(jsonResponse, new TypeReference<List<DropDownList>>() {
				});
				logger.info("DropDown List is :" + dropDownList);
			} else if (httpStatusCode == 500) {
				context.addMessage(null, new FacesMessage(i18nResourceBundle.getString("method.loginverify.failure")));
			}
		
		return dropDownList;
	}

	/**
	 * @return List<Employee>
	 * 
	 * this method consumes REST web service to get the list of employees.
	 * @throws IOException, SQLException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	public List<Employee> getEmployeeList() throws JsonParseException, JsonMappingException, IOException, SQLException {
		logger.info("Entered into getEmployeeList() method");
		List<Employee> employeeList = null;
		FacesContext context = FacesContext.getCurrentInstance();
		ResourceBundle i18nResourceBundle = context.getApplication().getResourceBundle(context, "msg");
		String url = "http://localhost:8007/jsf-xmlbased-springmvc-rest-webservices/employees";
			CloseableHttpClient httpClient = HttpClients.createDefault();
			HttpGet httpRequest = new HttpGet(url);
			httpRequest.addHeader("content-type", "application/json;charset=UTF-8");
			httpRequest.addHeader("charset", "UTF-8");
			HttpResponse httpResponse = (HttpResponse) httpClient.execute(httpRequest);
			int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
			logger.info("Http Response is : " + httpResponse);
			logger.info("Http status code is :" + httpStatusCode);
			if (httpStatusCode == 200) {
				HttpEntity entity = httpResponse.getEntity();
				logger.info("Http Response Body is :" + entity);
				String jsonResponse = EntityUtils.toString(entity);
				logger.info("Http Response body in JSON format :" + jsonResponse);
				ObjectMapper mapper = new ObjectMapper();
				employeeList = mapper.readValue(jsonResponse, new TypeReference<List<Employee>>() {
				});
				logger.info("Size of Employee  List is :" + employeeList.size());
			} else if (httpStatusCode == 500) {
				context.addMessage(null, new FacesMessage(i18nResourceBundle.getString("method.loginverify.failure")));
			}
		return employeeList;
	}
}
