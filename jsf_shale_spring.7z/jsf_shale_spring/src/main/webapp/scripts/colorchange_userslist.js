/**
 * this to execute the colorchange() function on window load
 */
window.onload = colorchange;
function colorchange() {
	document.getElementById("header:customersList").style.backgroundColor = "#993399";
}